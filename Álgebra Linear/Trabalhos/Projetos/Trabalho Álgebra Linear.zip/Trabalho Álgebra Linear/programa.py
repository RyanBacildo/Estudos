from boxtool import menu as mn

def main():
    mn.start_menu()

if __name__ == "__main__":
    main()